var intervalId = window.setInterval(function(){
    test();
  }, 100);
  document.getElementsByClassName("not-this-month").style.backgroundColor = '#85C1E9';

function test(){
    


    var x = document.getElementById("StartTime8").value;
    var y = document.getElementById("EndTime8").value;
    
    var a = document.getElementById("StartTime7").value;
    var b = document.getElementById("EndTime7").value;
    
    var c = document.getElementById("StartTime9").value;
    var d = document.getElementById("EndTime9").value;

    var e = document.getElementById("StartTime10").value;
    var f = document.getElementById("EndTime10").value;

    var g = document.getElementById("StartTime11").value;
    var h = document.getElementById("EndTime11").value;

    var i = document.getElementById("StartTime12").value;
    var j = document.getElementById("EndTime12").value;

    var k = document.getElementById("StartTime13").value;
    var l = document.getElementById("EndTime13").value;

    var m = document.getElementById("StartTime14").value;
    var n = document.getElementById("EndTime14").value;

    var o = document.getElementById("StartTime15").value;
    var oo = document.getElementById("EndTime15").value;

    var p = document.getElementById("StartTime16").value;
    var pp = document.getElementById("EndTime16").value;

    var q = document.getElementById("StartTime17").value;
    var qq = document.getElementById("EndTime17").value;

    var r = document.getElementById("StartTime18").value;
    var rr = document.getElementById("EndTime18").value;

    var s = document.getElementById("StartTime19").value;
    var ss = document.getElementById("EndTime19").value;

    var t = document.getElementById("StartTime20").value;
    var tt = document.getElementById("EndTime20").value;

    var u = document.getElementById("StartTime21").value;
    var uu = document.getElementById("EndTime21").value;

    var v = document.getElementById("StartTime22").value;
    var vv = document.getElementById("EndTime22").value;

    var w = document.getElementById("StartTime23").value;
    var ww = document.getElementById("EndTime23").value;

    var z = document.getElementById("StartTime24").value;
    var zz = document.getElementById("EndTime24").value;

    var aaa = document.getElementById("StartTime25").value;
    var aaaa = document.getElementById("EndTime25").value;

    var bbb = document.getElementById("StartTime26").value;
    var bbbb = document.getElementById("EndTime26").value;

    var ccc = document.getElementById("StartTime27").value;
    var cccc = document.getElementById("EndTime27").value;

    var ddd = document.getElementById("StartTime28").value;
    var dddd = document.getElementById("EndTime28").value;

    var eee = document.getElementById("StartTime29").value;
    var eeee = document.getElementById("EndTime29").value;

    var fff = document.getElementById("StartTime30").value;
    var ffff = document.getElementById("EndTime30").value;

    var ggg = document.getElementById("StartTime31").value;
    var gggg = document.getElementById("EndTime31").value;

    var hhh = document.getElementById("StartTime32").value;
    var hhhh = document.getElementById("EndTime32").value;

    var iii = document.getElementById("StartTime33").value;
    var iiii = document.getElementById("EndTime33").value;

    var jjj = document.getElementById("StartTime34").value;
    var jjjj = document.getElementById("EndTime34").value;

    var kkk = document.getElementById("StartTime0").value;
    var kkkk = document.getElementById("EndTime0").value;

    var lll = document.getElementById("StartTime1").value;
    var llll = document.getElementById("EndTime1").value;

    var mmm = document.getElementById("StartTime2").value;
    var mmmm = document.getElementById("EndTime2").value;

    var nnn = document.getElementById("StartTime3").value;
    var nnnn = document.getElementById("EndTime3").value;

    var ooo = document.getElementById("StartTime4").value;
    var oooo = document.getElementById("EndTime4").value;

    var ppp = document.getElementById("StartTime5").value;
    var pppp = document.getElementById("EndTime5").value;

    var qqq = document.getElementById("StartTime6").value;
    var qqqq = document.getElementById("EndTime6").value;


    
    if(x==y){
        document.getElementById("indx8").style.backgroundColor = '#ff6666';
        
        
        
      // alert(x);
    }
    if(x!=y){
        document.getElementById("indx8").style.backgroundColor = '#85C1E9 ';
    }

    if(a==b){
        document.getElementById("indx7").style.backgroundColor = '#ff6666';
    
    }
    if(a!=b){
        document.getElementById("indx7").style.backgroundColor = '#85C1E9 ';
    }
    if(c==d){
        document.getElementById("indx9").style.backgroundColor = '#ff6666';
   
    }
    if(c!=d){
        document.getElementById("indx9").style.backgroundColor = '#85C1E9 ';
    }
    if(e==f){
        document.getElementById("indx10").style.backgroundColor = '#ff6666';
       
    }
    if(e!=f){
        document.getElementById("indx10").style.backgroundColor = '#85C1E9 ';
    }

    if(g==h){
        document.getElementById("indx11").style.backgroundColor = '#ff6666';            
    }
    if(g!=h){
        document.getElementById("indx11").style.backgroundColor = '#85C1E9 ';
    }

    if(i==j){
        document.getElementById("indx12").style.backgroundColor = '#ff6666';            
    }
    if(i!=j){
        document.getElementById("indx12").style.backgroundColor = '#85C1E9 ';
    }
    
    if(k==l){
        document.getElementById("indx13").style.backgroundColor = '#ff6666';            
    }
    if(k!=l){
        document.getElementById("indx13").style.backgroundColor = '#85C1E9 ';
    }
    
    if(m==n){
        document.getElementById("indx14").style.backgroundColor = '#ff6666';            
    }
    if(m!=n){
        document.getElementById("indx14").style.backgroundColor = '#85C1E9 ';
    }
    
    if(o==oo){
        document.getElementById("indx15").style.backgroundColor = '#ff6666';            
    }
    if(o!=oo){
        document.getElementById("indx15").style.backgroundColor = '#85C1E9 ';
    }
    
    if(p==pp){
        document.getElementById("indx16").style.backgroundColor = '#ff6666';            
    }
    if(p!=pp){
        document.getElementById("indx16").style.backgroundColor = '#85C1E9 ';
    }
    if(q==qq){
        document.getElementById("indx17").style.backgroundColor = '#ff6666';            
    }
    if(q!=qq){
        document.getElementById("indx17").style.backgroundColor = '#85C1E9 ';
    }
    if(r==rr){
        document.getElementById("indx18").style.backgroundColor = '#ff6666';            
    }
    if(r!=rr){
        document.getElementById("indx18").style.backgroundColor = '#85C1E9 ';
    }
    if(s==ss){
        document.getElementById("indx19").style.backgroundColor = '#ff6666';            
    }
    if(s!=ss){
        document.getElementById("indx19").style.backgroundColor = '#85C1E9 ';
    }
    if(t==tt){
        document.getElementById("indx20").style.backgroundColor = '#ff6666';            
    }
    if(t!=tt){
        document.getElementById("indx20").style.backgroundColor = '#85C1E9 ';
    }
    if(u==uu){
        document.getElementById("indx21").style.backgroundColor = '#ff6666';            
    }
    if(u!=uu){
        document.getElementById("indx21").style.backgroundColor = '#85C1E9 ';
    }
    if(v==vv){
        document.getElementById("indx22").style.backgroundColor = '#ff6666';            
    }
    if(v!=vv){
        document.getElementById("indx22").style.backgroundColor = '#85C1E9 ';
    }
    if(w==ww){
        document.getElementById("indx23").style.backgroundColor = '#ff6666';            
    }
    if(w!=ww){
        document.getElementById("indx23").style.backgroundColor = '#85C1E9 ';
    }
    if(z==zz){
        document.getElementById("indx24").style.backgroundColor = '#ff6666';            
    }
    if(z!=zz){
        document.getElementById("indx24").style.backgroundColor = '#85C1E9 ';
    }
    if(aaa==aaaa){
        document.getElementById("indx25").style.backgroundColor = '#ff6666';            
    }
    if(aaa!=aaaa){
        document.getElementById("indx25").style.backgroundColor = '#85C1E9 ';
    }
    if(bbb==bbbb){
        document.getElementById("indx26").style.backgroundColor = '#ff6666';            
    }
    if(bbb!=bbbb){
        document.getElementById("indx26").style.backgroundColor = '#85C1E9 ';
    }
    if(ccc==cccc){
        document.getElementById("indx27").style.backgroundColor = '#ff6666';            
    }
    if(ccc!=cccc){
        document.getElementById("indx27").style.backgroundColor = '#85C1E9 ';
    }

    if(ddd==dddd){
        document.getElementById("indx28").style.backgroundColor = '#ff6666';            
    }
    if(ddd!=dddd){
        document.getElementById("indx28").style.backgroundColor = '#85C1E9 ';
    }

    if(eee==eeee){
        document.getElementById("indx29").style.backgroundColor = '#ff6666';            
    }
    if(eee!=eeee){
        document.getElementById("indx29").style.backgroundColor = '#85C1E9 ';
    }

    if(fff==ffff){
        document.getElementById("indx30").style.backgroundColor = '#ff6666';            
    }
    if(fff!=ffff){
        document.getElementById("indx230").style.backgroundColor = '#85C1E9 ';
    }

    if(ggg==gggg){
        document.getElementById("indx31").style.backgroundColor = '#ff6666';            
    }
    if(ggg!=gggg){
        document.getElementById("indx31").style.backgroundColor = '#85C1E9 ';
    }

    if(hhh==hhhh){
        document.getElementById("indx32").style.backgroundColor = '#ff6666';            
    }
    if(hhh!=hhhh){
        document.getElementById("indx32").style.backgroundColor = '#85C1E9 ';
    }
    if(iii==iiii){
        document.getElementById("indx33").style.backgroundColor = '#ff6666';            
    }
    if(iii!=iiii){
        document.getElementById("indx33").style.backgroundColor = '#85C1E9 ';
    }
    if(jjj==jjjj){
        document.getElementById("indx34").style.backgroundColor = '#ff6666';            
    }
    if(jjj!=jjjj){
        document.getElementById("indx34").style.backgroundColor = '#85C1E9 ';
 }

 if(kkk==kkkk){
    document.getElementById("indx0").style.backgroundColor = '#ff6666';            
}
if(kkk!=kkkk){
    document.getElementById("indx0").style.backgroundColor = '#85C1E9 ';
}

if(lll==llll){
    document.getElementById("indx1").style.backgroundColor = '#ff6666';            
}
if(lll!=llll){
    document.getElementById("indx1").style.backgroundColor = '#85C1E9 ';
}

if(mmm==mmmm){
    document.getElementById("indx2").style.backgroundColor = '#ff6666';            
}
if(mmm!=mmmm){
    document.getElementById("indx2").style.backgroundColor = '#85C1E9 ';
}

if(nnn==nnnn){
    document.getElementById("indx3").style.backgroundColor = '#ff6666';            
}
if(nnn!=nnnn){
    document.getElementById("indx3").style.backgroundColor = '#85C1E9 ';
}

if(ooo==oooo){
    document.getElementById("indx4").style.backgroundColor = '#ff6666';            
}
if(ooo!=oooo){
    document.getElementById("indx4").style.backgroundColor = '#85C1E9 ';
}

if(ppp==pppp){
    document.getElementById("indx5").style.backgroundColor = '#ff6666';            
}
if(ppp!=pppp){
    document.getElementById("indx5").style.backgroundColor = '#85C1E9 ';
}

if(qqq==qqqq){
    document.getElementById("indx6").style.backgroundColor = '#ff6666';            
}
if(qqq!=qqqq){
    document.getElementById("indx6").style.backgroundColor = '#85C1E9 ';
}
}